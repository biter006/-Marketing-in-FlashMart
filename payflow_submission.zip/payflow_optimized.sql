-- PAYFLOW: phân tích và tối ưu báo cáo tiền nạp tháng 06 năm 2026.
CREATE DATABASE IF NOT EXISTS payflow_db;
USE payflow_db;

CREATE TABLE IF NOT EXISTS Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(15, 2),
    transaction_type VARCHAR(20),
    created_at DATETIME
);

-- Kế hoạch cũ: YEAR() và MONTH() khiến created_at không SARGable.
-- Hãy chạy phần này trước khi chạy CREATE INDEX để quan sát Full Table Scan.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6;

-- Composite B-Tree Index khớp cột lọc bằng và cột lọc theo khoảng thời gian.
CREATE INDEX idx_type_date ON Transactions(transaction_type, created_at);

-- Kế hoạch mới: điều kiện Range dùng được phần created_at của Index.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at < '2026-07-01 00:00:00';

-- Câu truy vấn báo cáo tối ưu để sử dụng trong ứng dụng.
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at < '2026-07-01 00:00:00';
