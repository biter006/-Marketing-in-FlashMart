# Nhật ký trao đổi AI về Index và SARGable

## YEAR và MONTH trên cột đã đánh chỉ mục

**Prompt:** Vì sao `WHERE YEAR(created_at) = 2026` có thể không sử dụng Index của `created_at` trong MySQL?

**Kết quả áp dụng:** Hàm phải được tính trên từng giá trị `created_at`, khiến MySQL không thể xác định trực tiếp đoạn khóa liên tiếp trong B-Tree. Điều kiện được viết lại thành khoảng thời gian với `>=` và `<`.

## Thứ tự Composite Index

**Prompt:** Với điều kiện `transaction_type = 'DEPOSIT'` và `created_at` trong một tháng, thứ tự `(transaction_type, created_at)` có phù hợp không?

**Kết quả áp dụng:** Có. Cột đầu dùng điều kiện bằng, sau đó cột ngày dùng điều kiện range. Index khớp thứ tự lọc của mệnh đề `WHERE`.

## Đọc EXPLAIN

**Prompt:** `type = ALL`, `range` và `ref` trong EXPLAIN thể hiện điều gì?

**Kết quả áp dụng:** `ALL` là quét toàn bảng. `range` là quét một khoảng khóa trong Index. `ref` là tra cứu bằng giá trị tham chiếu hoặc hằng số. Với báo cáo tháng, mục tiêu là không còn `ALL` và `key` hiển thị `idx_type_date`.
