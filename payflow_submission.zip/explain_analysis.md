# So sánh EXPLAIN trước và sau tối ưu

Truy vấn cũ bọc cột `created_at` bằng `YEAR()` và `MONTH()`. Đây là điều kiện non-SARGable: MySQL không thể dùng thứ tự B-Tree của ngày giờ để xác định trực tiếp đoạn dữ liệu tháng 06. Trước khi tạo chỉ mục, `EXPLAIN` thường có `type = ALL`, `possible_keys = NULL` và `rows` gần bằng toàn bộ bảng Transactions.

Sau khi tạo `idx_type_date(transaction_type, created_at)`, truy vấn mới lọc `transaction_type = 'DEPOSIT'` và dùng khoảng thời gian `[2026-06-01, 2026-07-01)`. `EXPLAIN` cần hiển thị `possible_keys` hoặc `key` là `idx_type_date`; `type` thường là `range` (hoặc `ref` tùy dữ liệu và optimizer). Giá trị `rows` là ước lượng chỉ những giao dịch nạp trong tháng 06, thấp hơn đáng kể so với quét toàn bảng. Hai truy vấn trả cùng tổng tiền nhưng truy vấn mới giảm lượng dữ liệu cần đọc.
